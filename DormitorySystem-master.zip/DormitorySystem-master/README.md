"# DormitorySystem"

Java + mysql 学生宿舍管理系统

采用MVC的设计模式，是java学习阶段的小项目，仅供学习使用


### 数据库连接相关
```
private static final String url = "jdbc:mysql://localhost:3306/domitory";
private static final String user = "root";
private static final String password = "666666";
```
将JDBC文件夹里的db.java文件里的数据库连接地址、用户名、密码改为自己的
