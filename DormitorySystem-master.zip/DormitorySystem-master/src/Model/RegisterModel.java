package Model;

public class RegisterModel {
	private Integer identity;
	private Integer accountt;
	private String password;

	public Integer getAccountt() {
		return accountt;
	}

	public void setAccountt(Integer accountt) {
		this.accountt = accountt;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Integer getIdentity() {
		return identity;
	}

	public void setIdentity(Integer identity) {
		this.identity = identity;
	}

}
