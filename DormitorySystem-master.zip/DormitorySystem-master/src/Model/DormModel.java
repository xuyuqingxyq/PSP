package Model;

public class DormModel {

	private String dorm_id;
	private Integer bed_num;
	private Integer people_num;

	public String getDorm_id() {
		return dorm_id;
	}

	public void setDorm_id(String dorm_id) {
		this.dorm_id = dorm_id;
	}

	public Integer getBed_num() {
		return bed_num;
	}

	public void setBed_num(Integer bed_num) {
		this.bed_num = bed_num;
	}

	public Integer getPeople_num() {
		return people_num;
	}

	public void setPeople_num(Integer people_num) {
		this.people_num = people_num;
	}
}
